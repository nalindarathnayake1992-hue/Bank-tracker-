package com.example.smartbanktracker

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony

class SmsReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Telephony.Sms.Intents.SMS_RECEIVED_ACTION) return
        val db = TransactionDb(context)
        Telephony.Sms.Intents.getMessagesFromIntent(intent).forEach { sms ->
            val body = sms.messageBody ?: return@forEach
            if (Regex("""(?i)\b(OTP|one.?time password|verification code)\b""").containsMatchIn(body)) return@forEach
            BankParser.parse(body, sms.originatingAddress.orEmpty())?.let { db.insert(it) }
        }
    }
}
