package com.example.smartbanktracker

import java.util.Locale

object BankParser {
    fun parse(message: String, sender: String = ""): Transaction? {
        val text = message.replace(",", "").trim()
        val amount = Regex("""(?i)(?:LKR\s*|Rs\.?\s*)([0-9]+(?:\.[0-9]{1,2})?)\s*(?:has been )?(credited|deposited|received|debited|withdrawn|deducted)?""")
            .find(text)?.groupValues?.getOrNull(1)?.toDoubleOrNull()
            ?: Regex("""(?i)(?:amount|txn|transaction)\s*[:=]?\s*(?:LKR|Rs\.?)?\s*([0-9]+(?:\.[0-9]{1,2})?)""")
                .find(text)?.groupValues?.getOrNull(1)?.toDoubleOrNull()
            ?: return null

        val debit = Regex("""(?i)\b(debit(?:ed)?|withdrawn|deducted|purchase|spent|paid)\b""").containsMatchIn(text)
        val credit = Regex("""(?i)\b(credit(?:ed)?|deposit(?:ed)?|received|transfer in)\b""").containsMatchIn(text)
        val type = when {
            debit -> "DEBIT"
            credit -> "CREDIT"
            else -> return null
        }
        val balance = Regex("""(?i)Bal(?:ance)?\s*[:=]?\s*(?:LKR|Rs\.?)?\s*([0-9]+(?:\.[0-9]{1,2})?)""")
            .find(text)?.groupValues?.getOrNull(1)?.toDoubleOrNull()
        val date = Regex("""\b\d{1,2}[/-]\d{1,2}[/-]\d{2,4}(?:\s+\d{1,2}:\d{2}(?::\d{2})?)?""")
            .find(text)?.value ?: "Date not found"

        val bank = when {
            text.contains("Hatton National Bank", true) || sender.contains("HNB", true) -> "HNB"
            text.contains("Commercial Bank", true) -> "Commercial Bank"
            text.contains("Sampath", true) -> "Sampath Bank"
            text.contains("People's Bank", true) -> "People's Bank"
            text.contains("Bank of Ceylon", true) || Regex("""\bBOC\b""", RegexOption.IGNORE_CASE).containsMatchIn(text) -> "BOC"
            text.contains("NDB", true) -> "NDB"
            text.contains("DFCC", true) -> "DFCC"
            text.contains("Pan Asia", true) -> "Pan Asia Bank"
            text.contains("NSB", true) -> "NSB"
            else -> if (sender.isNotBlank()) sender.take(30) else "Unknown bank"
        }
        val description = when {
            text.contains("JustPay", true) -> "JustPay"
            text.contains("ATM", true) -> "ATM"
            text.contains("POS", true) -> "Card/POS"
            text.contains("salary", true) -> "Salary"
            text.contains("fund transfer", true) -> "Fund transfer"
            else -> "Bank transaction"
        }
        val key = "$bank|$type|$amount|${balance ?: ""}|$date|$description"
        return Transaction(bank = bank, type = type, amount = amount, balance = balance,
            dateText = date, description = description, sourceKey = key)
    }
}
