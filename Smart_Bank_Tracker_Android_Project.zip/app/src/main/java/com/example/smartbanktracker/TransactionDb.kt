package com.example.smartbanktracker

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class TransactionDb(context: Context) : SQLiteOpenHelper(context, "bank_tracker.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""CREATE TABLE transactions (
            id INTEGER PRIMARY KEY AUTOINCREMENT, bank TEXT NOT NULL, type TEXT NOT NULL,
            amount REAL NOT NULL, balance REAL, date_text TEXT, description TEXT, source_key TEXT UNIQUE
        )""")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}
    fun insert(t: Transaction): Boolean {
        val v = ContentValues().apply {
            put("bank", t.bank); put("type", t.type); put("amount", t.amount)
            if (t.balance == null) putNull("balance") else put("balance", t.balance)
            put("date_text", t.dateText); put("description", t.description); put("source_key", t.sourceKey)
        }
        return try { writableDatabase.insertOrThrow("transactions", null, v); true } catch (_: Exception) { false }
    }
    fun all(): List<Transaction> {
        val out = mutableListOf<Transaction>()
        readableDatabase.rawQuery("SELECT * FROM transactions ORDER BY id DESC LIMIT 100", null).use { c ->
            while (c.moveToNext()) {
                val bi = c.getColumnIndexOrThrow("balance")
                out += Transaction(
                    id = c.getLong(c.getColumnIndexOrThrow("id")),
                    bank = c.getString(c.getColumnIndexOrThrow("bank")),
                    type = c.getString(c.getColumnIndexOrThrow("type")),
                    amount = c.getDouble(c.getColumnIndexOrThrow("amount")),
                    balance = if (c.isNull(bi)) null else c.getDouble(bi),
                    dateText = c.getString(c.getColumnIndexOrThrow("date_text")) ?: "",
                    description = c.getString(c.getColumnIndexOrThrow("description")) ?: "",
                    sourceKey = c.getString(c.getColumnIndexOrThrow("source_key")) ?: ""
                )
            }
        }
        return out
    }
}
