package com.example.smartbanktracker

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import android.graphics.Color
import java.text.NumberFormat
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var db: TransactionDb
    private lateinit var root: LinearLayout
    private val money = NumberFormat.getNumberInstance(Locale.US).apply {
        minimumFractionDigits = 2; maximumFractionDigits = 2
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db = TransactionDb(this)
        val scroll = ScrollView(this)
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 28, 24, 24) }
        scroll.addView(root); setContentView(scroll)
        root.addView(TextView(this).apply { text = "Smart Bank Tracker"; textSize = 25f; setTextColor(Color.rgb(25,55,45)) })
        root.addView(TextView(this).apply { text = "Bank SMS transactions • Stored on this phone"; textSize = 14f })
        val input = EditText(this).apply {
            hint = "Paste bank SMS here..."; minLines = 4; gravity = Gravity.TOP
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
        }
        root.addView(input, params())
        root.addView(Button(this).apply {
            text = "Read SMS text"
            setOnClickListener {
                val t = BankParser.parse(input.text.toString())
                if (t == null) Toast.makeText(this@MainActivity, "Credit/Debit not recognised. Please check the SMS.", Toast.LENGTH_LONG).show()
                else {
                    val ok = db.insert(t)
                    Toast.makeText(this@MainActivity, if (ok) "Transaction added" else "Already added", Toast.LENGTH_SHORT).show()
                    input.text.clear(); render()
                }
            }
        }, params())
        root.addView(Button(this).apply { text = "Refresh"; setOnClickListener { render() } }, params())
        render()
        if (checkSelfPermission(Manifest.permission.RECEIVE_SMS) != PackageManager.PERMISSION_GRANTED ||
            checkSelfPermission(Manifest.permission.READ_SMS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECEIVE_SMS, Manifest.permission.READ_SMS), 100)
        }
    }
    private fun params() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = 12 }
    private fun render() {
        while (root.childCount > 5) root.removeViewAt(5)
        val list = db.all()
        val balance = list.firstOrNull { it.balance != null }?.balance
        val credit = list.filter { it.type == "CREDIT" }.sumOf { it.amount }
        val debit = list.filter { it.type == "DEBIT" }.sumOf { it.amount }
        fun label(s: String, size: Float, color: Int = Color.BLACK, bold: Boolean = false) {
            root.addView(TextView(this).apply {
                text = s; textSize = size; setTextColor(color)
                if (bold) setTypeface(null, android.graphics.Typeface.BOLD)
                setPadding(0, 12, 0, 5)
            })
        }
        label("LATEST BANK BALANCE", 13f, Color.DKGRAY, true)
        label(balance?.let { "LKR ${money.format(it)}" } ?: "No balance found yet", 27f, Color.rgb(8,127,91), true)
        label("Credit total: LKR ${money.format(credit)}", 16f, Color.rgb(8,127,91), true)
        label("Debit total: LKR ${money.format(debit)}", 16f, Color.rgb(190,55,55), true)
        label("Recent transactions", 20f, Color.BLACK, true)
        if (list.isEmpty()) label("No transactions yet. Paste an SMS or allow SMS permission.", 14f, Color.DKGRAY)
        list.forEach { t ->
            val sign = if (t.type == "CREDIT") "+" else "-"
            val color = if (t.type == "CREDIT") Color.rgb(8,127,91) else Color.rgb(190,55,55)
            label("$sign LKR ${money.format(t.amount)} • ${t.type}", 17f, color, true)
            label("${t.bank} | ${t.description} | ${t.dateText}" +
                (t.balance?.let { " | Balance LKR ${money.format(it)}" } ?: ""), 12f, Color.DKGRAY)
        }
    }
}
