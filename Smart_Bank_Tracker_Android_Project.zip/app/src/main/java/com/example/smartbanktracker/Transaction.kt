package com.example.smartbanktracker
data class Transaction(
    val id: Long = 0, val bank: String, val type: String, val amount: Double,
    val balance: Double?, val dateText: String, val description: String, val sourceKey: String
)
