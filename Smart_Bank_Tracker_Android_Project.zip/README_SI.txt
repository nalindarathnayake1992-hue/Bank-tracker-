SMART BANK TRACKER - Android Studio starter project

1. ZIP එක extract කරන්න.
2. Android Studio > Open > SmartBankTracker folder එක තෝරන්න.
3. Gradle Sync අවසන් වූ පසු Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Debug APK එක app/build/outputs/apk/debug/app-debug.apk යටතේ ලැබේ.

ඇතුළත් දේ:
- SMS Auto Read සඳහා incoming SMS receiver.
- SMS copy/paste කර manually import කිරීම.
- Credit / Debit, amount, date, bank සහ SMS balance හඳුනාගැනීම.
- SQLite local storage; මුල් SMS body එක database එකේ ගබඩා නොකරයි.
- Duplicate imports වළක්වන unique key එකක්.
- OTP / verification code ලෙස හඳුනාගන්නා SMS import නොකරයි.

සීමා සහ ආරක්ෂාව:
- මෙය starter project එකක්; සියලුම ශ්‍රී ලාංකික බැංකු SMS formats පරීක්ෂා කර නැත.
- නොහඳුනාගත් SMS හෝ වැරදි වර්ගීකරණයක් manually verify කරන්න.
- SMS permission ඉල්ලන්නේ auto-read සඳහාය. අවසරය නොදුන්නොත් manual paste පමණක් භාවිතා කරන්න.
- Android/Google Play SMS permission policy නිසා Play Store publishing සීමා විය හැක; පුද්ගලික testing/sideload සඳහාය.
- Balance එක SMS එකකින් ලැබුණු අවසන් bank-reported balance එකයි. සියලු SMS නොලැබුණොත් එය සැබෑ බැංකු balance එකෙන් වෙනස් විය හැක.
- APK එක විශ්වාස කරන device එකක පමණක් install කරන්න. OTP, PIN, password හෝ සම්පූර්ණ account details කිසිවෙකුට share නොකරන්න.
- තවම edit/delete, opening balance, export, biometric lock සහ bank-specific format testing ඇතුළත් නැත.
